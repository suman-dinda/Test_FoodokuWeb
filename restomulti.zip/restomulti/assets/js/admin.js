function clear_elements(ele) {	
    $("#"+ele).find(':input').each(function() {						    	
        switch(this.type) {
            case 'password':
            case 'select-multiple':
            case 'select-one':
            case 'text':
            case 'textarea':
                $(this).val('');
                break;
            case 'checkbox':
            case 'radio':
                this.checked = false;            
            
        }
   });
   
   $(".preview").remove();
}

$.validate({ 	
	language : jsLanguageValidator,
    form : '#forms',    
    onError : function() {      
    },
    onSuccess : function() {     
      form_submit();
      return false;
    }  
});

$.validate({ 	
	language : jsLanguageValidator,
    form : '#frm-pop',    
    onError : function() {      
    },
    onSuccess : function() {     
      form_submit('frm-pop');
      return false;
    }  
});

$.validate({ 	
	language : jsLanguageValidator,
    form : '#mt-frm',    
    onError : function() {      
    },
    onSuccess : function() {     
      form_submit('mt-frm');
      return false;
    }  
});

$.validate({ 	
	language : jsLanguageValidator,
    form : '#mt-frm-activation',    
    onError : function() {      
    },
    onSuccess : function() {     
      form_submit('mt-frm-activation');
      return false;
    }  
});

$.validate({ 	
	language : jsLanguageValidator,
    form : '#frm-creditcard',    
    onError : function() {      
    },
    onSuccess : function() {           
      form_submit('frm-creditcard');
      return false;
    }  
});

$.validate({ 		
	language : jsLanguageValidator,
    form : '#frm-smsbroadcast',    
    onError : function() {      
    },
    onSuccess : function() {       
      var broadcast_type=$("#send_to:checked").val();
      //////console.debug(broadcast_type);
      if ( broadcast_type ==1 || broadcast_type == 2){
      	  var total=0;
      	  if ( broadcast_type ==1 ){
      	  	  total=$("#total_customer").val();
      	  } else if ( broadcast_type == 2 ){
      	  	 total=$("#total_customer_by_merchant").val();
      	  }
          var a=confirm(js_lang.trans_19+" ("+total+") "+js_lang.trans_20+"\n"+js_lang.trans_18);    
          if (a){
            form_submit('frm-smsbroadcast');
          }
      } else {
      	 form_submit('frm-smsbroadcast');
      }
      return false;
    }  
});

function busy(e)
{
    if (e) {
        $('body').css('cursor', 'wait');	
    } else $('body').css('cursor', 'auto');        
    
    if (e) {
    	$("body").before("<div class=\"preloader\"></div>");
    } else $(".preloader").remove();
    
}

function scroll(id){
   if( $('#'+id).is(':visible') ) {	
      $('html,body').animate({scrollTop: $("#"+id).offset().top-100},'slow');
   }
}

function toogle(id , bool , caption)
{
    $('#'+id).attr("disabled", bool );
    $("#"+id).val(caption);
}

function rm_notices()
{
	$(".uk-alert").remove();		    
}

function form_submit(formid)
{			
	rm_notices();
    //var form_id=$("form").attr("id");    
    if ( formid ) {
		var form_id=formid;
	} else {
		var form_id=$("form").attr("id");    
	}   
    
	var btn=$('#'+form_id+' input[type="submit"]');   	
    var btn_cap=btn.val();
    btn.attr("disabled", true );
    btn.val(js_lang.processing);
    busy(true);    
    
    var action=$('#'+form_id).find("#action").val(); 
    
	var params=$("#"+form_id).serialize();	
	
	params+="&currentController="+$("#currentController").val();
	
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){ 
        	busy(false);  
        	btn.attr("disabled", false );
        	btn.val(btn_cap);        	
        	//scroll(form_id);
        	if (data.code==1){
        		//$("#"+form_id).before("<p class=\"uk-alert uk-alert-success\">"+data.msg+"</p>");
        		uk_msg_sucess(data.msg);
        		
        		if ( action=="switchMerchantAccount"){
        			window.location.href=data.details;
        		}
        		
        		if (action=="addMerchant"){
        			var old_status=$("#old_status").val();
        			var new_status=$("#status").val();        			
        			if ( old_status=="" || old_status!=new_status){
	        			var params="action=sendEmailMerchant&backend=true"+"&currentController="+
	        			$("#currentController").val()+"&id="+$("#id").val()+"&tbl=sendEmailMerchant";
	                    open_fancy_box(params);
        			}
        		}
        		if (action=="sendEmailToMerchant"){
        			close_fb();
        		}
        		
        		if ( action=="merchantForgotPass" || action=="adminForgotPass"){
        			$(".mt-frm").hide();
        			$(".mt-frm-activation").show();
        			$("#email").val( $("#email_address").val() );
        			
        			if ( action=="adminForgotPass" ){
        				$(".uk-form").show();
        			}
        			return;
        		}
        		if ( action=="merchantChangePassword"){
        			$(".forms").show();
        			$(".mt-frm").hide();        			
        			$(".mt-frm-activation").hide();
        			return;
        		}
        		
        		if ( $("#redirect").length>=1 ){
        			if (typeof data.details === "undefined" || data.details==null ) {        			    		
        			    window.location.replace(  $("#redirect").val() );
        			} else {
        				window.location.replace(  $("#redirect").val()+"/id/"+data.details );
        			}
        		}
        		        		
        		if ( action=="UpdateMerchant"){
        			load_map();
        		}        		
        		
        		if (action=="updateOrder"){
        			table_reload();
        			close_fb();
        			
        			// show sms message pop 
        			if (data.details.show_sms==2){
	        			var params="action=showSMS&tbl=showSMS&backend=true"+
	        			"&currentController="+$("#currentController").val()+
	        			"&order_id="+data.details.order_id;
	                    open_fancy_box(params);       
        			}			
        		}
        		
        		if ( action=="sendUpdateOrderSMS" || action=="sendUpdateOrderEmail"){
        			close_fb();
        		}
        		
        		if (action=="updatePaymennt"){
        			table_reload();
        			close_fb();
        		}
        		
        		if (action=="updateMerchantStatus"){
        			table_reload();
        			close_fb();
        		}        		
        		        		
        		if (action=="initSelectPaymentProvider" || action=="initpaymentprovider" || action=="paymentPaypalVerification" ){
        			//window.location.replace( data.details);
        			window.location.href=data.details;
        			return;
        		}        		
        		
        		if ( action=="addCreditCardMerchant"){
        			loadCreditCardListMerchant();
        		}
        		
        		if ( action=="payCC"){
        			//window.location.replace(sites_url+"/merchant/smsReceipt/id/"+data.details);
        			window.location.href=sites_url+"/merchant/smsReceipt/id/"+data.details;
        			return;
        		}
        		if ( action=="PayPaypal"){
        			//window.location.replace(data.details);
        			window.location.href=data.details;
        			return;
        		}
        		
        		if (action=="FaxbankDepositVerification"){
        			clear_elements('forms');
        		}        	
        		
        	} else {
        		//$("#"+form_id).before("<p class=\"uk-alert uk-alert-danger\">"+data.msg+"</p>");
        		uk_msg(data.msg);
        	}
        	        	
        	/*setTimeout(function () {
               $(".uk-alert").fadeOut();
            }, 5000);        	*/
        }, 
        error: function(){	        	
        	btn.attr("disabled", false );
        	btn.val(btn_cap);
        	busy(false);        	
        	//$("#"+form_id).before("<p class=\"uk-alert uk-alert-danger\">ERROR:</p>");
        	uk_msg(data.msg);
        	/*setTimeout(function () {
               $(".uk-alert").fadeOut();
            }, 5000);  */
        }		
    });
}

var otable;

jQuery(document).ready(function() {
	
	jQuery.fn.exists = function(){return this.length>0;}
	
	if( $('.chosen').is(':visible') ) {     
       //$(".chosen").chosen(); 
       $(".chosen").chosen({
       	  allow_single_deselect:true,
       	  no_results_text: js_lang.trans_33,
          placeholder_text_single: js_lang.trans_32, 
          placeholder_text_multiple: js_lang.trans_32
       }); 	
    } 
    
    if( $('.icheck').is(':visible') ) { 
	     $('.icheck').iCheck({
	       checkboxClass: 'icheckbox_minimal',
	       radioClass: 'iradio_flat'
	     });
    }
    
    if( $('.merchant-add').is(':visible') ) { 
	     $('.icheck').iCheck({
	       checkboxClass: 'icheckbox_minimal',
	       radioClass: 'iradio_flat'
	     });
    }
    
    if( $('#table_list').is(':visible') ) {    	
    	table();    	
    } 
    
    if( $('#table_list2').is(':visible') ) {    	
    	table2();    	
    } 
    
    if( $('#table_list3').is(':visible') ) {    	
    	table3();    	
    } 
    
    $("#table_list").on({	
	   mouseenter: function(){    	    
	    $(this).find(".options").show();
	  },
	   mouseleave: function () {	   
	    $(this).find(".options").hide();
	}},'tbody tr');	    	
	
	$( document ).on( "click", ".row_del", function() {
        var ans=confirm(js_lang.deleteWarning);        
        if (ans){        	
        	row_delete( $(this).attr("rev"),$("#tbl").val(), $(this));        	        
        }
    });
    
    if( jQuery('#photo').is(':visible') ) {    	
       createUploader('photo','photo');
    }     
    if( jQuery('#photo2').is(':visible') ) {    	
       createUploader('photo2','photo2');
    }     
    if( jQuery('#files').is(':visible') ) {    	
       createUploader('files','files');
    }     
    
    if( jQuery('#gallery').is(':visible') ) {    	
       createUploader('gallery','gallery');
    }     
    
    $('.numeric_only').keyup(function () {     
      this.value = this.value.replace(/[^0-9\.]/g,'');
    });	
    
    $( document ).delegate( ".multi_option", "change", function() {	
    	var parent=$(this).parent().parent();
    	////////console.debug(parent);
    	if ( $(this).val() =="custom"){    	
    		parent.find(".multi_option_value").show();	
    	} else {    	
    		parent.find(".multi_option_value").val("");
    		parent.find(".multi_option_value").hide();
    	}        
    });	
    
    $( document ).on( "click", ".addnewprice", function() {
    	var html=$(".price_wrap").html();    	
    	//$(".price_wrap").after("<li class=\"\">"+html+"</li>");
    	$(".price_wrap_parent li:last").prev().after("<li class=\"\">"+html+"</li>");
    });
    
    $( document ).on( "click", ".removeprice", function() {
    	var parent=$(this).parent().parent().parent();
    	parent.remove();
    });
    
    var website_date_picker_format="yy-mm-dd";
    if ( $("#website_date_picker_format").exists()){
    	website_date_picker_format= $("#website_date_picker_format").val();
    }
    dump(website_date_picker_format);
    
    jQuery(".j_date").datepicker( { 
       dateFormat: website_date_picker_format,        
       altFormat: "yy-mm-dd",       
       changeMonth: true, 
       changeYear: true ,      
	   yearRange: "-10:+10",
	   prevText: js_lang.datep_1,
		nextText: js_lang.datep_2,
		currentText: js_lang.datep_3,
		monthNames: [js_lang.January,js_lang.February,js_lang.March,js_lang.April,js_lang.May,js_lang.June,
		js_lang.July,js_lang.August,js_lang.September,js_lang.October,js_lang.November,js_lang.December],
		monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
		js_lang.Jul, js_lang.Aug, js_lang.Sep, js_lang.Oct, js_lang.Nov, js_lang.Dec],
		dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		dayNamesMin: [js_lang.Su,js_lang.Mo,js_lang.Tu,js_lang.We,js_lang.Th,js_lang.Fr,js_lang.Sa],						
		isRTL: false,
		onSelect : function( element, object ) {
			var original_id=$(this).data("id");
			dump(original_id);
			var altFormat = $(this).datepicker('option', 'altFormat');
			var currentDate = $(this).datepicker('getDate');
			var formatedDate = $.datepicker.formatDate(altFormat, currentDate);
			dump(formatedDate);
			$("#"+original_id).val(formatedDate);
		}
	});	  
	
	var show_period=false;
	if ( $("#website_time_picker_format").exists() ){		
		if ( $("#website_time_picker_format").val()=="12"){
			show_period=true;
		}
	}
	dump(show_period);
	
	jQuery('.timepick').timepicker({  
		showPeriod: show_period,      
        hourText: js_lang.Hour,       
		minuteText: js_lang.Minute,  
		amPmText: [js_lang.AM, js_lang.PM]
    });
    
    $( ".sortable_ul" ).sortable({
       	update: function( event, ui ) {       		
       		//sort_list( $(this) );
       	},
       	 change: function( event, ui ) {
       	 	////////console.debug('d2');
       	 }
    }); 
        
    $( document ).on( "click", ".view-map", function() {    	
       load_map();
    });
    
    $( document ).on( "click", ".remove-merchant-logo", function() {    	
        var a=confirm(js_lang.trans_4);
        if (a){
        	remove_logo();
        }    
    });
    
    $( document ).on( "click", ".remove-merchant-bg", function() {    	
        var a=confirm(js_lang.trans_4);
        if (a){
        	remove_merchant_bg();
        }    
    });
    
    $( document ).on( "click", ".view-receipt", function() {    	       	 	
   	   var params="action=viewReceipt&tbl=viewReceipt&id="+ $(this).data("id")+"&backend=true"+"&currentController="+$("#currentController").val();
       open_fancy_box(params);
   });	
   
   $( document ).on( "click", ".print_element", function() {    	       	 	
       //$('.receipt-main-wrap').print();
       $('.receipt-main-wrap').printElement();
   });	
      
   $( document ).on( "click", ".edit-order", function() {    	       	 	      
       var params="action=editOrder&tbl=viewReceipt&id="+ $(this).data("id")+"&currentController="+$("#currentController").val();
       open_fancy_box(params);
   });	
      
   $( ".export_btn" ).click(function(){
      var params="action=export&rpt="+$(this).attr("rel")+"&tbl=export";
      window.open(ajax_url+"?"+params);      
   });
   
   $( document ).on( "click", ".edit-payment", function() {    	       	 	      
       var params="action=editPayment&tbl=editPayment&id="+ $(this).data("id");
       open_fancy_box(params);
   });	
   
   
   $( document ).on( "click", ".edit-merchant-status", function() {    	       	 	      
       var params="action=editMerchantStatus&tbl=editMerchantStatus&id="+ $(this).data("id");
       open_fancy_box(params);
   });	

   
   
   if( $('.is_ready').is(':visible') ) {	
      get_merchant_status();
   }
     
   $('.is_ready').on('ifChecked', function(event){    	
    	merchant_set_ready(2);
   });
   $('.is_ready').on('ifUnchecked', function(event){    	
    	merchant_set_ready(1);
   });
      
       
    $( ".sortable-jquery" ).sortable();
    
    
    $( document ).on( "click", ".mt-fp-link", function() {    	    
    	$(".mt-frm").slideDown();
    	$(".forms").slideUp();
    	$(".mt-frm-activation").hide();
    });  
    $( document ).on( "click", ".mt-login-link", function() {    	    
    	//////console.debug('d2');    	
    	$(".forms").show();
    	$(".mt-frm").hide();
    	$(".mt-frm-activation").hide();
    });      
    
        
    if ( $("#alert_off").val()=="" ) {		
    	////console.debug("alert_off");
	    $("#jquery_jplayer_1").jPlayer({
		    ready: function () {
		       $(this).jPlayer("setMedia", {
		          mp3: sites_url+"/assets/sound/notify.mp3"	          	         
		       });
		    },
		    swfPath: sites_url+"/assets/vendor/jQuery.jPlayer.2.6.0/",
		    supplied: "m4a,mp3"
	    });        	    
	}   
	
	//if ( $("#alert_off").val()=="" ){	 	
	if ( $("#currentController").val()=="merchant" ){
	 	new_order_notify = setInterval(function(){get_new_order()}, 7000);
	}	
	//}
	
	if ( $("#booking_alert").exists() ){				
		if ( $("#booking_alert").val()=="" ){				
		 	new_order_notify = setInterval(function(){get_booking()}, 7000);
		}
	}
	
	$('.payment_option').on('ifChecked', function(event){
       ////console.debug( $(this).val() );
   });
   
   $('.send_to').on('ifChecked', function(event){    	    	
    	if ( $(this).val() == 3){
    		$(".custom_wrap_mobile").slideDown();
    		$("#list_mobile_number").attr("data-validation","required");
    	} else  {
    		$(".custom_wrap_mobile").slideUp();
    		$("#list_mobile_number").removeAttr("data-validation");
    	}
   });
   
   if( $('#sms_alert_message').is(':visible') ) {           			
       $('#sms_alert_message').restrictLength($('#maxlength'));
   }
      
   if( $('#merchant').is(':visible') ) {    
   	   ////console.debug('d2');       			
       get_sell_limit_status();
   }
   
   $( document ).on( "click", ".select_all", function() {    	          	      	   
   	   $(".access").attr('checked', true);   	      	   
   	   
   });
   $( document ).on( "click", ".unselect_all", function() {    	          	      	   
   	   $(".access").attr('checked',false);   	   
   });   
   
   $( document ).on( "click", ".view_vouchers", function() {    	          	      	   
   	   var id=$(this).data("id");   	   
   	   var params="action=voucherdetails&tbl=voucherdetails&id="+ $(this).data("id")+"&backend=true";
       open_fancy_box(params);
   });   
   
   $( document ).on( "click", ".get-coordinates", function() {
   	   var address = $("#street").val() + " "+ $("#city").val() + " "+ $("#state").val()  ;
   	   address+=" "+$("#country_code").val()
   	   //console.debug(address);
   	   //var a=confirm("Is this address correct? \n"+address);
   	   var a=confirm(js_lang.trans_50+"? \n"+address);
   	   if (a){
   	   	  geocode_address(address);
   	   	  //alert("You can drag the map marker");
   	   	  alert(js_lang.trans_49);
   	   }      	   
   });   	  
    
});/* END DOCUMENT*/

function debug(t)
{
	//console.debug(t);
}

function get_new_order()
{			
	var params="action=getNewOrder";
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){      
        	if (data.code==1){        		   
        		if ( $(".merchant-dashboard").exists() ) {
        		    table_reload();
        		}
        		if( $('.uk-notify').is(':visible') ) {           			
        		} else {              			
        			if ( $("#alert_off").val()=="" ){	        				
        			   $("#jquery_jplayer_1").jPlayer("play");  			        			
        			} else {        				
        			}
        			$.UIkit.notify({
		       	   	   message : data.msg+" "+js_lang.NewOrderStatsMsg+data.details
		       	    }); 	       	        
        		}
        	}
        }, 
        error: function(){        	
        }		
    });
}

function get_sell_limit_status()
{	
	var params="action=getLimitSellStatus&currentController=merchant";
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){   
        	if (data.code==2){
        		$.UIkit.notify({
	               message :data.msg,
	               pos:'bottom-right',
	               status:'danger',
	               timeout :8500,	  
	            });	    	   	   	  
        	}         	
        }, 
        error: function(){        	
        }		
    });
}

var epp_table;
var epp_table2;
var epp_table3;

function load_map()
{
	if ( $("#merchant_latitude").val() =="" && $("#merchant_longtitude").val()==""){
   	  $("#google_map_wrap").hide();
    } else {    
   	  $("#google_map_wrap").show();
      locations=[[$("#restaurant_name").val(),$("#merchant_latitude").val(),$("#merchant_longtitude").val(),16]];
      initializeMarker(locations);         	    
    }
}

function table()
{		    
	
	if ( $(".selected_transaction_query").exists() ){
		var query=$("#query").val();				
		switch(query){
			case "last30":
			$(".last30").addClass("uk-button-success");
			break;
			case "last15":
			$(".last15").addClass("uk-button-success");
			break;
			case "month":
			  var query_date="selected-"+$("#query_date").val();			  
			  $("."+query_date).addClass("uk-button-success");
			break;
			
			case "all":			  
			$(".all").addClass("uk-button-success");
			break;
		}
	}
	
	var action=$("#action").val();		
	var server_side=false;
	if (action=="merchantList"){
	    server_side=true;
	}
		
	var params=$("#frm_table_list").serialize();
	params+="&currentController="+$("#currentController").val();
    epp_table = $('#table_list').dataTable({
    	   "iDisplayLength": 15,
	       "bProcessing": true, 
	       //"bServerSide": false,
	       "bServerSide": server_side,
	       "sAjaxSource": ajax_url+"?"+params,	       
	       "aaSorting": [[ 0, "desc" ]],
	       "oLanguage":{	       	 
	       	 "sProcessing": "<p>Processing.. <i class=\"fa fa-spinner fa-spin\"></i></p>"
	       },
	       "oLanguage": {
	       	  "sEmptyTable":    js_lang.tablet_1,
			    "sInfo":           js_lang.tablet_2,
			    "sInfoEmpty":      js_lang.tablet_3,
			    "sInfoFiltered":   js_lang.tablet_4,
			    "sInfoPostFix":    "",
			    "sInfoThousands":  ",",
			    "sLengthMenu":     js_lang.tablet_5,
			    "sLoadingRecords": js_lang.tablet_6,
			    "sProcessing":     js_lang.tablet_7,
			    "sSearch":         js_lang.tablet_8,
			    "sZeroRecords":    js_lang.tablet_9,
			    "oPaginate": {
			        "sFirst":    js_lang.tablet_10,
			        "sLast":     js_lang.tablet_11,
			        "sNext":     js_lang.tablet_12,
			        "sPrevious": js_lang.tablet_13
			    },
			    "oAria": {
			        "sSortAscending":  js_lang.tablet_14,
			        "sSortDescending": js_lang.tablet_15
			    }
	       },
	       "fnInitComplete": function(oSettings, json) {
	       	  var action=$("#action").val();	     	       	  
		      if ( action=="merchantCommissionDetails"){		      	  
		      	  $(".merchant_name").html(json.merchant_name);
		      	  $(".total_commission").html(json.total_commission);
		      }
		      if ( action=="merchantStatement"){		      	  
		      	  $(".total_amount").html(json.total_amount);		      	  
		      	  if ( $("#payment_type").val()==2){
		      	  	 $(".cash_tr").show();
		      	     $(".total_payable").html(json.total_payable);
		      	  }
		      }
		      
		      if (action=="merchantCommission"){
		      	  $(".total_commission").html(json.total_commission);
		      }
		      
		    }
    });		
}

function table2()
{		
	var params=$("#frm_table_list2").serialize();
    epp_table2 = $('#table_list2').dataTable({
	       "bProcessing": true, 
	       "bServerSide": false,
	       "sAjaxSource": ajax_url+"?"+params,	       
	       "aaSorting": [[ 0, "desc" ]],
	       "oLanguage":{	       	 
	       	 "sProcessing": "<p>Processing.. <i class=\"fa fa-spinner fa-spin\"></i></p>"
	       },
	       "oLanguage": {
	       	  "sEmptyTable":    js_lang.tablet_1,
			    "sInfo":           js_lang.tablet_2,
			    "sInfoEmpty":      js_lang.tablet_3,
			    "sInfoFiltered":   js_lang.tablet_4,
			    "sInfoPostFix":    "",
			    "sInfoThousands":  ",",
			    "sLengthMenu":     js_lang.tablet_5,
			    "sLoadingRecords": js_lang.tablet_6,
			    "sProcessing":     js_lang.tablet_7,
			    "sSearch":         js_lang.tablet_8,
			    "sZeroRecords":    js_lang.tablet_9,
			    "oPaginate": {
			        "sFirst":    js_lang.tablet_10,
			        "sLast":     js_lang.tablet_11,
			        "sNext":     js_lang.tablet_12,
			        "sPrevious": js_lang.tablet_13
			    },
			    "oAria": {
			        "sSortAscending":  js_lang.tablet_14,
			        "sSortDescending": js_lang.tablet_15
			    }
	       }	       
    });		
}

function table3()
{		
	var params=$("#frm_table_list3").serialize();
    epp_table3 = $('#table_list3').dataTable({
	       "bProcessing": true, 
	       "bServerSide": false,
	       "sAjaxSource": ajax_url+"?"+params,	       
	       "aaSorting": [[ 0, "desc" ]],
	       "oLanguage":{	       	 
	       	 "sProcessing": "<p>Processing.. <i class=\"fa fa-spinner fa-spin\"></i></p>"
	       },
	       "oLanguage": {
	       	  "sEmptyTable":    js_lang.tablet_1,
			    "sInfo":           js_lang.tablet_2,
			    "sInfoEmpty":      js_lang.tablet_3,
			    "sInfoFiltered":   js_lang.tablet_4,
			    "sInfoPostFix":    "",
			    "sInfoThousands":  ",",
			    "sLengthMenu":     js_lang.tablet_5,
			    "sLoadingRecords": js_lang.tablet_6,
			    "sProcessing":     js_lang.tablet_7,
			    "sSearch":         js_lang.tablet_8,
			    "sZeroRecords":    js_lang.tablet_9,
			    "oPaginate": {
			        "sFirst":    js_lang.tablet_10,
			        "sLast":     js_lang.tablet_11,
			        "sNext":     js_lang.tablet_12,
			        "sPrevious": js_lang.tablet_13
			    },
			    "oAria": {
			        "sSortAscending":  js_lang.tablet_14,
			        "sSortDescending": js_lang.tablet_15
			    }
	       }	       
    });		
}

function table_reload()
{	
	epp_table.fnReloadAjax(); 
}

function sales_summary_reload()
{
	var params=$("#frm_table_list").serialize();
	console.debug(params);
    /*epp_table = $('#table_list').dataTable({
	       "bProcessing": true, 
	       "bServerSide": false,
	       "sAjaxSource": ajax_url+"?"+params,	       
	       "aaSorting": [[ 0, "desc" ]]	       
    });		*/
	epp_table.fnReloadAjax(ajax_url+"?"+params); 
}


function row_delete(id,tbl,object)
{		
	var form_id=$("form").attr("id");
	rm_notices();	
	busy(true);
	var params="action=rowDelete&tbl="+tbl+"&row_id="+id+"&whereid="+$("#whereid").val();	
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){
        	busy(false);
        	if (data.code==1){       
        		$("#"+form_id).before("<div class=\"uk-alert uk-alert-success\">"+data.msg+"</div>");         		
        		tr=object.closest("tr");
                tr.fadeOut("slow");
        	} else {      
        		$("#"+form_id).before("<div class=\"uk-alert uk-alert-danger\">"+data.msg+"</div>");
        	}        	        	
        }, 
        error: function(){	        	        	
        	busy(false);
        	$("#"+form_id).before("<div class=\"uk-alert uk-alert-danger\">ERROR:</div>");
        }		
    });
}

function photo(data)
{
	var img='';
	//////console.debug(data);
	$(".preview").show();
	img+="<img src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\"uk-thumbnail uk-thumbnail-mini\" >";
	img+="<input type=\"hidden\" name=\"photo\" value=\""+data.details.file+"\" >";
	img+="<p><a href=\"javascript:rm_preview();\">"+js_lang.removeFeatureImage+"</a></p>";
	$(".image_preview").html(img);
}

function photo2(data)
{
	var img='';	
	$(".preview2").show();
	img+="<img src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\"uk-thumbnail uk-thumbnail-mini\" >";
	img+="<input type=\"hidden\" name=\"photo2\" value=\""+data.details.file+"\" >";
	img+="<p><a href=\"javascript:rm_preview2();\">"+js_lang.removeFeatureImage+"</a></p>";
	$(".image_preview2").html(img);
	$(".image_preview2").show();
}

function files(data)
{
	var img='';	
	$(".preview2").show();
	img+="<p>"+data.details.file+"</p>";
	img+="<input type=\"hidden\" name=\"language_file\" value=\""+data.details.file+"\" >";
	img+="<p><a href=\"javascript:rm_preview();\">"+js_lang.removeFiles+"</a></p>";
	$(".image_preview").html(img);
	$(".image_preview").show();
}

function rm_preview()
{
	$(".image_preview").html('');
}

function rm_preview2()
{
	$(".image_preview2").html('');
}

function remove_logo()
{
	var params="action=removeLogo";
	busy(true);
    $.ajax({    
    type: "POST",
    url: ajax_url,
    data: params,
    dataType: 'json',       
    success: function(data){ 
    	busy(false);      
    	if (data.code==1){
    		if (data.code==1){
    			$(".image_preview").hide();
    		}
    	} else {
    	   uk_msg(data.msg);
    	}
    }, 
    error: function(){	        	    	
    	busy(false); 
    }		
    });
}

function remove_merchant_bg()
{
	var params="action=removeMerchantBg";
	busy(true);
    $.ajax({    
    type: "POST",
    url: ajax_url,
    data: params,
    dataType: 'json',       
    success: function(data){ 
    	busy(false);      
    	if (data.code==1){
    		if (data.code==1){
    			$(".image_preview2").hide();
    			$('input[name="photo2"]').remove();
    		}
    	} else {
    	   uk_msg(data.msg);
    	}
    }, 
    error: function(){	        	    	
    	busy(false); 
    }		
    });
}

function uk_msg(msg)
{
	$.UIkit.notify({
	   message :msg,
	   timeout :1500,	   
	});	    	   	   	  
}

function uk_msg_sucess(msg)
{
	$.UIkit.notify({
	   message :msg,
	   timeout :1500,	   
	   status:'success'
	});	    	   	   	  
}

function open_fancy_box(params)
  {  	  	  	  	
	var URL=ajax_url+"/?"+params;
	$.fancybox({        
	maxWidth:800,
	closeBtn : false,          
	autoSize : true,
	padding :0,
	margin :2,
	modal:false,
	type : 'ajax',
	href : URL,
	openEffect :'elastic',
	closeEffect :'elastic'	
	});   
}

function close_fb()
{
	$.fancybox.close(); 
}

/*=============================================================
START GOOGLE MAP MARKER
=============================================================*/
function initializeMarker(locations){	

    window.map = new google.maps.Map(document.getElementById('google_map_wrap'), {
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        scrollwheel: false
        //styles: [ {stylers: [ { "saturation":-100 }, { "lightness": 0 }, { "gamma": 0.5 }]}]
    });
        
    var infowindow = new google.maps.InfoWindow();

    var bounds = new google.maps.LatLngBounds();

    for (i = 0; i < locations.length; i++) {
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map
            //icon: hl_template_url + '/images/google_mapicon.png'
        });

        bounds.extend(marker.position);

        google.maps.event.addListener(marker, 'click', (function (marker, i) {
            return function () {
                infowindow.setContent(locations[i][0]);
                infowindow.open(map, marker);
            }
        })(marker, i));
    }

    map.fitBounds(bounds);

    var listener = google.maps.event.addListener(map, "idle", function () {
        map.setZoom(18); /*16*/
        google.maps.event.removeListener(listener);
    });
}
/*=============================================================
END GOOGLE MAP MARKER
=============================================================*/

jQuery(document).ready(function() {	
	if( $('.chart').is(':visible') ) {	
	   load_totalsales_chart();	
	   load_total_sales_chart_by_item();
	}
}); /*END DOCU*/

function load_totalsales_chart()
{
	$.jqplot.config.enablePlugins = true;
	var ajaxDataRenderer = function(url, plot, options) {
    var ret = null;
    $.ajax({    
      async: false,
      url: url,
      dataType:"json",
      success: function(data) {
        ret = data;
      }
    });
    return ret;
    };
    
    var jsonurl = ajax_url+"/?action=chartTotalSales&tbl=chart&currentController="+$("#currentController").val();    
          
    var plot1 = $.jqplot('total_sales_chart', jsonurl,{
     animate: true,
     title: js_lang.lastTotalSales ,
     seriesDefaults:{
            renderer:$.jqplot.BarRenderer,
            pointLabels: { show: true },
            rendererOptions:{  varyBarColor: true }
     },     
       axesDefaults: {
        tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
        tickOptions: {
          angle: -30,
          fontSize: '10pt',
        }
    },
     grid:{
    		drawGridLines: false,
    		gridLineColor: '#cccccc',
    		backgroundColor: "#eee",
    		drawBorder: false,
    		borderColor: '#999999',   
    		borderWidth: 1.0,
    		shadow: false
     },
     axes: {
            xaxis: {
                renderer: $.jqplot.CategoryAxisRenderer,
                //ticks: ticks
            }
     },
     dataRenderer: ajaxDataRenderer,
     dataRendererOptions: {
        unusedOptionalUrl: jsonurl,
     }
   });
}

function load_total_sales_chart_by_item()
{
	$.jqplot.config.enablePlugins = true;
	var ajaxDataRenderer = function(url, plot, options) {
    var ret = null;
    $.ajax({    
      async: false,
      url: url,
      dataType:"json",
      success: function(data) {
        ret = data;
      }
    });
    return ret;
    };
    
    var jsonurl = ajax_url+"/?action=chartByItem&tbl=chart&currentController="+$("#currentController").val();
          
    var plot2 = $.jqplot('total_sales_chart_by_item', jsonurl,{
     animate: true,
     title: js_lang.lastItemSales,
     seriesDefaults:{
            renderer:$.jqplot.BarRenderer,
            pointLabels: { show: true },
            rendererOptions:{  varyBarColor: true }
     },
       axesDefaults: {
        tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
        tickOptions: {
          angle: -30,
          fontSize: '10pt',
        }
    },
     grid:{
    		drawGridLines: false,
    		gridLineColor: '#cccccc',
    		backgroundColor: "#eee",
    		drawBorder: false,
    		borderColor: '#999999',   
    		borderWidth: 1.0,
    		shadow: false
     },
     axes: {
            xaxis: {
                renderer: $.jqplot.CategoryAxisRenderer,
                //ticks: ticks
            }
     },
     dataRenderer: ajaxDataRenderer,
     dataRendererOptions: {
        unusedOptionalUrl: jsonurl,
     }
   });
}

function merchant_set_ready(status)
{			
	busy(true);
	var params="action=merchantSetReady&status="+status;
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){
        	busy(false);
        	uk_msg(data.msg);
        	if (data.code==1){    
        		$("#notice-merchant-stats").remove();             		
        	} else {              		
        	}        	        	
        }, 
        error: function(){	        	        	
        	busy(false);        	
        }		
    });
}

function get_merchant_status()
{				
	busy(true);
	var params="action=merchantStatus&currentController="+$("#currentController").val();
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){
        	busy(false);        	
        	dump(data.details);
        	if (data.code==1){    
        		if (data.msg==2){        			
        			$('.is_ready').prop('checked', true);           			
        		} else {
        			$('.is_ready').prop('checked', false);   
$('.notice-wrap').before("<div id=\"notice-merchant-stats\" class=\"uk-badge uk-badge-danger\">"+js_lang.trans_17+"</div>");
        		}
        		$(".merchant-status").text(js_lang.Status+" "+data.details.display_status);
        		if (data.details.status=="expired"){
        			$(".merchant-status").addClass("uk-badge uk-badge-danger");
        			
        			$.UIkit.notify({
	                  message :js_lang.merchantStats,
	                  pos:'bottom-right',
	                  status:'danger',
	                  timeout :8500,	   
	                });	    	   	   	  
        			
        		} else if(data.details.status=="active"){
        			$(".merchant-status").addClass("uk-badge uk-badge-success");
        		} else{
        			$(".merchant-status").addClass("uk-badge uk-badge-notification");
        		}        
        		        		        		
        		if ( data.details.is_commission==2){
        			$(".merchant-status").attr("href","javascript:;");
        		}
        				
        	} else {              		
        		$('.is_ready').prop('checked', false);   
        	}        	        	
        	$('.is_ready').iCheck('update'); 
        }, 
        error: function(){	        	        	
        	$('.is_ready').prop('checked', false);   
        	busy(false);        	
        }		
    });
}

jQuery(document).ready(function() {	
	
	if( $('#frm-creditcard').is(':visible') ) {	
       loadCreditCardListMerchant();
	}
	
   $( document ).on( "click", ".cc-add", function() {    	  
   	   $(".cc-add-wrap").slideToggle("fast");
   });   
	
   jQuery.fn.exists = function(){return this.length>0;}
   
   if ( $("#payuForm").exists() ){
    	if ( $("#hash").val()=="" ){    		    	
    	} else {
    		$(".uk-button").attr("disabled",true);    		
    		$(".uk-button").css({ 'pointer-events' : 'none' });
    		$("#payuForm").submit();
    	}
   }
   if ( $("#payu_status").exists() ){
    	$(".uk-button").attr("disabled",true);    		
        $(".uk-button").css({ 'pointer-events' : 'none' });
   }    
   
   if ( $("#merchant").exists() ){
        getGoogleCordinateStatus();
   }
   
   if ( $(".big-textarea").exists() ){
   	    $(".big-textarea").jqte();
   }
      
   $( document ).on( "click", ".add_new_holiday", function() {    	  
       var t='';
       t+='<div class="holiday_row">';
       t+='<input type="text" name="merchant_holiday[]" class="j_date small_date" >';
       t+='<a href="javascript:;" class="remove_holiday"><i class="fa fa-minus-square"></i></a>';
       t+='</div>';
   	   $(".holiday_list").append(t);
   	   initDate();
   });   
      
   $( document ).on( "click", ".remove_holiday", function() {    	  
   	  var t=$(this).parent();
   	  t.remove();
   });   
   	
   /*$( document ).on( "click", ".view-details", function() {    	  
   	   var where=$(this).data("where");   	   
   	   var mtid=$(this).data("id");
   	   var and=$(this).data("and");
   	   dump(where);
   	   dump(and);
   	   dump(mtid);
   	   var url=admin_url+"/merchantcommissiondetails/mtid/"+mtid;
   	   url+="/where/"+encodeURIComponent(where);
   	   url+="/and/"+encodeURIComponent(and);
   	   dump(url);
   	   window.location.replace(url);
   });   */
   
   $( document ).on( "change", "#sms_package_id", function() {    	
       var selected=$(this).val();
       getPackageInformation(selected);
   });
   
}); /*END DOCU*/

function loadCreditCardListMerchant()
{
	var htm='';
	var params="action=loadCreditCardListMerchant&merchant_id="+$("#merchant_id").val();
	busy(true);
    $.ajax({    
    type: "POST",
    url: ajax_url,
    data: params,
    dataType: 'json',       
    success: function(data){ 
    	busy(false);      	
    	if (data.code==1){    		    		    		    	
    		$.each(data.details, function( index, val ) {
    			$(".uk-list-cc li").remove(); 
    			htm+='<li>';
	              htm+='<div class="uk-grid">';
	                htm+='<div class="uk-width-1-2">'+val.credit_card_number+'</div>';
	                htm+='<div class="uk-width-1-2">&nbsp;<input class="icheck" type="radio" name="cc_id" class="cc_id" value="'+val.mt_id+'"></div>';
	              htm+='</div>';
	            htm+='</li>';
    		});
    		$(".uk-list-cc").append(htm);
    		$(".cc-add-wrap").hide();
    		
    		$('.icheck').iCheck({
	          checkboxClass: 'icheckbox_minimal',
	          radioClass: 'iradio_flat'
	       });
    		
    	}
    }, 
    error: function(){	        	    	
    	busy(false); 
    }		
    });
}

function geocode_address(address)
{		
	$("#google_map_wrap").show();
	var geocoder;
    var map;
    geocoder = new google.maps.Geocoder(); 
    var mapOptions = {
	   scrollwheel: false,	
	   zoom: 18,
	   //center: latlng,
	   mapTypeId: google.maps.MapTypeId.ROADMAP
	 }
	 map = new google.maps.Map(document.getElementById('google_map_wrap'), mapOptions);
	 
	 geocoder.geocode( { 'address': address}, function(results, status) {
	 	  //dump(results);
	 	  ////console.debug(status);
	 	  /*//console.debug(results[0].geometry.location.k);
	 	  //console.debug(results[0].geometry.location.B);*/
	 	  if (status == google.maps.GeocoderStatus.OK) {
	 	  	
	 	  	  var result_lat=results[0].geometry.location.lat();
	 	  	  var result_lng=results[0].geometry.location.lng();
	 	  	  
	 	  	  $("#merchant_latitude").val(result_lat);
	 	  	  $("#merchant_longtitude").val(result_lng);
	 	  	  
	 	  	  /*$("#merchant_latitude").val(results[0].geometry.location.k);
	 	  	  if (typeof results[0].geometry.location.B === "undefined" || results[0].geometry.location.B ) { 
	 	  	  	 $("#merchant_longtitude").val(results[0].geometry.location.D);
	 	  	  } else {
	 	  	     $("#merchant_longtitude").val(results[0].geometry.location.B);
	 	  	  }*/
		      map.setCenter(results[0].geometry.location);
			  var marker = new google.maps.Marker({    	
			     map: map,
			     position: results[0].geometry.location,
			     draggable:true
			  });			
			  
			   google.maps.event.addListener(marker,'drag',function(event) {			   	   
                   $("#merchant_latitude").val( event.latLng.lat() );                   
                   $("#merchant_longtitude").val( event.latLng.lng() );
               }); 
			    
	 	  } else {
	 	  	 uk_msg(status);
	 	  }
	 });
}

function getGoogleCordinateStatus()
{	
	var params="action=getGoogleCordinateStatus";
	busy(true);
    $.ajax({    
    type: "POST",
    url: ajax_url,
    data: params,
    dataType: 'json',       
    success: function(data){ 
    	busy(false);      	
    	if (data.code==2){  
    		$.UIkit.notify({
	         message :data.msg,
	         pos: 'bottom-right',
	         status:'warning',
	         timeout :5000,	   
	        });	    	   	   	      		    	
    	}
    }, 
    error: function(){	        	    	
    	busy(false); 
    }		
    });	
}

function dump(data)
{
	console.debug(data);
}

function get_booking()
{		
	var params="action=getNewBooking";
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){      
        	if (data.code==1){        		        	
        		if( $('.uk-notify').is(':visible') ) {           			
        		} else {      
        			if ( $("#alert_off").val()=="" ) {
        			    $("#jquery_jplayer_1").jPlayer("play");  			
        			}
        			$.UIkit.notify({
		       	   	   //message : data.msg+" "+js_lang.trans_34	       	   	   
		       	   	   message : data.msg
		       	    }); 	       	        
        		}
        	}
        }, 
        error: function(){        	
        }		
    });
}

function gallery(data)
{	
	var img='';
	$(".preview").show();
	img+='<li>';
	img+="<img src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\""+data.details.id+" uk-thumbnail uk-thumbnail-mini\" >";
	img+="<input type=\"hidden\" name=\"photo[]\" value=\""+data.details.file+"\" class=\""+data.details.id+"\" >";
	img+="<p class=\""+data.details.id+"\"><a href=\"javascript:rm_gallery('"+data.details.id+"');\">"+js_lang.removeFeatureImage+"</a></p>";
	img+='</li>';
	$(".image_preview").append(img);
}

function rm_gallery(id)
{	
	dump(id);
	$("."+id).remove();
}

function initDate()
{
	jQuery(".j_date").datepicker( { dateFormat: 'yy-mm-dd' , changeMonth: true, changeYear: true ,
	   yearRange: "-10:+10",
	   prevText: js_lang.datep_1,
		nextText: js_lang.datep_2,
		currentText: js_lang.datep_3,
		monthNames: [js_lang.January,js_lang.February,js_lang.March,js_lang.April,js_lang.May,js_lang.June,
		js_lang.July,js_lang.August,js_lang.September,js_lang.October,js_lang.November,js_lang.December],
		monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
		js_lang.Jul, js_lang.Aug, js_lang.Sep, js_lang.Oct, js_lang.Nov, js_lang.Dec],
		dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		dayNamesMin: [js_lang.Su,js_lang.Mo,js_lang.Tu,js_lang.We,js_lang.Th,js_lang.Fr,js_lang.Sa],						
		isRTL: false
	});	  
}

function getPackageInformation(package_id)
{
	busy(true);
	var params="action=getPackageInformation&package_id="+package_id;
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){     
        	busy(false); 
        	if (data.code==1){          		
        		$("#sms_limit").val(data.details);
        	} else if ( data.code==3){        		
        		$("#sms_limit").val('');
        	} else {
        		uk_msg(data.msg);
        	}
        }, 
        error: function(){        
        	busy(false);	
        }		
    });
}


jQuery(document).ready(function() {	
	
	if ( $(".commission_total_1").exists() ){
		getCommissionTotal();
	}
	
	if ( $(".merchant_total_balance").exists() ){
		getMerchantBalance();
	}
	
	$( document ).on( "click", ".remove_notice", function() {    	  
		 busy(true);
   	     var params="action=removeNotice";
		 $.ajax({    
	        type: "POST",
	        url: ajax_url,
	        data: params,
	        dataType: 'json',       
	        success: function(data){   	        
	        	busy(false);
	        	if (data.code==1){
	        		$(".merchant_notice").remove();
	        	}
	        }, 
	        error: function(){        	        	
	        	busy(false);
	        }		
	    });
    });   
	
    
    $( document ).on( "click", ".li-click", function() {    	      	
    	$(".li-click").removeClass("active");
    	$(this).addClass("active");
    	$("#payment_type").val(  $(this).data("id") );
    	dump( $(this).data("id") );
    	
    	if ( $(this).data("id") =="single"){
    		$("#amount").attr("data-validation","required");
    	} else {
    		$("#amount").removeAttr("data-validation");
    	}
    });   
    $( document ).on( "click", ".li-click2", function() {    	      	
    	$(".li-click2").removeClass("active");
    	$(this).addClass("active");    	    	
    	$("#payment_method").val(  $(this).data("id") );
    	
    	    	
    	$("#minimum_amount").val( $(this).data("minimum") );
    	
    	if ( $(this).data("id") == "paypal"){
    		$(".paypal-account-wrap").slideDown();
    		$("#account").attr("data-validation","required");
    		$("#account_confirm").attr("data-validation","required");
    		
    		
    		$(".bank-info-wrap").slideUp();
    		bankRequired(false);
    		
    	} else {
    		$(".paypal-account-wrap").slideUp();
    		$("#account").removeAttr("data-validation");
    		$("#account_confirm").removeAttr("data-validation");
    		
    		$(".bank-info-wrap").slideDown();    
    		bankRequired(true);		
    	}
    });   
    
    $( document ).on( "click", ".togle-withdrawal", function() {    	      	
        $(".withdrawal-info").slideToggle();
    });   
    
    
    $( document ).on( "click", ".payout_action", function() {    	      	
    	var status=$(this).data("status");
    	var withdrawal_id=$(this).data("id");
    	var ans=confirm(js_lang.trans_18);
    	if (ans){
    		payoutChangeStatus(status,withdrawal_id);
    	}
    });   
    
    if ( $("#w-list").exists() ){
    	var selected=$("#w-list").val();    	
    	$(".w-list."+selected).addClass("uk-button-primary");
    }
    
    if ( $("#wd_payout_alert").exists() ){
    	var wd_payout_alert=$("#wd_payout_alert").val();    	
    	if ( wd_payout_alert=="2"){    		
    		new_order_notify = setInterval(function(){wdPayoutNotification()}, 7000);
    	}
    }    
        
    $( document ).on( "click", ".test-email", function() {    	      	
        var params="action=testEmail&backend=true"+"&currentController="+
		$("#currentController").val()+"&tbl=testEmail";
        open_fancy_box(params);
    });
    
    if( jQuery('#spicydish').is(':visible') ) {    	
       createUploader('spicydish','spicydish');
    }     
    
    $( document ).on( "click", ".view-bank-info", function() {    	      	
    	var withdrawal_id=$(this).data("id");
    	var params="action=viewBankInfo&backend=true"+"&currentController="+
		$("#currentController").val()+"&tbl=bankinfo&id="+withdrawal_id;
        open_fancy_box(params);
    });	
    
    
    $( document ).on( "click", ".add-table-rate", function() {    	      	
    	var count=$(".distance_from").length+1;
    	dump(count);
    	var html='';
    	html+="<tr class=\"shipping-row-"+count+"\">";
    	  html+="<td>";
    	  html+=$(".shipping-col-1").html();
    	  html+="</td>";
    	  html+="<td>";
    	  html+=$(".shipping-col-2").html();
    	  html+="</td>";
    	  html+="<td>";
    	  html+=$(".shipping-col-3").html();
    	  html+="</td>";
    	  
    	  html+="<td>";
    	  html+="<a href=\"javascript:;\" class=\"shipping-remove\" data-id=\""+count+"\"><i class=\"fa fa-times\"></i></a>";
    	  html+="</td>";
    	  
    	html+="</tr>";
    	$('.table-shipping-rates tr:last').after(html);
    });	
    
    
    $( document ).on( "click", ".shipping-remove", function() {    	      	
    	var id=$(this).data("id");    	
    	$(".shipping-row-"+id).remove();
    });	
    
    
	$( document ).on( "click", ".close-receipt", function() {
		close_fb();
	});
	
	if ( $(".mobile_inputs").exists()){
		 $(".mobile_inputs").intlTelInput({      
	        autoPlaceholder: false,
	        defaultCountry: $("#country_code").val(),    
	        autoHideDialCode:true,    
	        nationalMode:false,
	        autoFormat:false,
	        utilsScript: sites_url+"/assets/vendor/intel/lib/libphonenumber/build/utils.js"
	     });
	}
	
}); /*end docu*/

function getCommissionTotal()
{
	$(".commission_loader").html('<i class="fa fa-spinner fa-spin"></i>');
	var params="action=getCommissionTotal";
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){   
        	$(".commission_loader").html('');          	
        	$(".commission_total_3").html(data.details.total_com);
        	$(".commission_total_2").html(data.details.total_today);
        	$(".commission_total_1").html(data.details.total_last);
        }, 
        error: function(){        
        	$(".commission_loader").html('error');
        }		
    });
}

function getMerchantBalance()
{
	$(".commission_loader").html('<i class="fa fa-spinner fa-spin"></i>');
	var params="action=getMerchantBalance";
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){   
        	$(".commission_loader").html('');          	
        	$(".merchant_total_balance").html(data.details);        	
        }, 
        error: function(){        
        	$(".commission_loader").html('error');
        }		
    });
}

function bankRequired(is_required)
{
	if ( is_required ){
		$("#account_name").attr("data-validation","required");
		$("#bank_account_number").attr("data-validation","required");
		$("#swift_code").attr("data-validation","required");
		$("#bank_name").attr("data-validation","required");
		$("#bank_country").attr("data-validation","required");		
	} else {
		$("#account_name").removeAttr("data-validation");
		$("#bank_account_number").removeAttr("data-validation");
		$("#swift_code").removeAttr("data-validation");
		$("#bank_name").removeAttr("data-validation");
		$("#bank_country").removeAttr("data-validation");
	}
}

function payoutChangeStatus(status,withdrawal_id)
{
	var params="action=payoutChangeStatus&status="+status+"&withdrawal_id="+withdrawal_id;
	 $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){           	
        	if (data.code==1){
        		table_reload();
        	} else {
        		uk_msg_sucess(data.msg);
        	}
        }, 
        error: function(){        
        	uk_msg("Error");
        }		
    });
}

var ajaxwdPayoutNotification;

function wdPayoutNotification()
{
	if (ajaxwdPayoutNotification){
		ajaxwdPayoutNotification.abort();
	}
	
	var params="action=wdPayoutNotification";
	ajaxwdPayoutNotification = $.ajax({    
        type: "POST",
        url: ajax_url,
        data: params,
        dataType: 'json',       
        success: function(data){           	        	
        	if (data.code==1){
        		uk_msg(data.msg);
        	}
        }, 
        error: function(){                	
        }		
    });
}

function spicydish(data)
{
	var img='';	
	$(".preview_spicydish").show();
	img+="<img src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\"uk-thumbnail\" >";
	img+="<input type=\"hidden\" name=\"spicydish\" value=\""+data.details.file+"\" >";
	img+="<p><a href=\"javascript:rm_spicydish_preview();\">"+js_lang.removeFeatureImage+"</a></p>";
	$(".image_preview_spicydish").html(img);
}

function rm_spicydish_preview()
{
	$(".image_preview_spicydish").html('');
}

/** two flavors options */
jQuery(document).ready(function() {	
		
	$( document ).on( "click", ".two_flavors", function() {
		var value=$(".two_flavors:checked").val();
		dump(value);		
		show_hide_flavors(value);
	});
	
	if ( $(".two_flavors").exists() ){
		var value=$(".two_flavors:checked").val();		
		show_hide_flavors(value);
	}
		
	$( document ).on( "change", ".two_flavors_position", function() {
		var value=$(this).val();		
		dump(value);
		var data_id=$(this).data("id");
		dump(data_id);
		if ( value=="right" || value=="left"){
			$("#multi_option_"+data_id).val("one");
		}
	});
		
    $( document ).on( "change", ".multi_option", function() {		
		var data_id=$(this).data("id");
		dump(data_id);
		var value=$(this).val();		
		dump(value);
		if ( $("#two_flavors_position_"+data_id).is(':visible')){
			var value2=$("#two_flavors_position_"+data_id).val();
			dump(value2);
			if ( value2=="right" || value2=="left"){
				if ( value=="multiple" || value=="custom"){
					$(this).val("one");
					$("#multi_option_value_"+data_id).hide();
				}
			}
		}
	});
	
	
	$( document ).on( "click", ".test-sms", function() {
		var params="action=testSms&backend=true"+"&currentController="+
		$("#currentController").val()+"&tbl=backend";
        open_fancy_box(params);
	});
	
}); /*end docu*/

function show_hide_flavors(value)
{
	if ( value==2){
		$(".two_flavors_position").show();
	} else {
		$(".two_flavors_position").hide();
	}
}

$.validate({ 	
	language : jsLanguageValidator,
    form : '#forms-normal',    
    onError : function() {      
    },
    onSuccess : function() {     
      return true;
    }  
});


/*START version 2.1.1*/

jQuery(document).ready(function() {	
	
	$( document ).on( "click", ".admin-select-access", function() {
		$('.admin-acess').iCheck('check');
	});
	
	$( document ).on( "click", ".admin-unselect-access", function() {
		$('.admin-acess').iCheck('uncheck');
	});
	
	if( jQuery('#rphoto').is(':visible') ) {    			
         createUploader('rphoto','rphoto');
    }     
	
    
    $( document ).on( "click", ".voucher-details", function() {
        var params="action=viewVoucherDetails&backend=true"+"&currentController="+
		$("#currentController").val()+"&voucher_name="+encodeURIComponent($(this).data("id"))+"&tbl=viewVoucherDetails";
        open_fancy_box(params);
    });	                    
    
}); /*end class*/


function rphoto(data)
{
	var img='';	
	$(".rc_preview").show();
	img+="<img src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\"uk-thumbnail uk-thumbnail-mini\" >";
	img+="<input type=\"hidden\" name=\"website_receipt_logo\" value=\""+data.details.file+"\" >";
	img+="<p><a href=\"javascript:rc_rm_preview();\">"+js_lang.removeFeatureImage+"</a></p>";
	$(".rc_image_preview").html(img);	
}

function rc_rm_preview()
{
	$(".rc_image_preview").html('');
}

jQuery(document).ready(function() {	
	if ( $(".j_date_normal").exists()){
	    jQuery(".j_date_normal").datepicker({ 
	    	dateFormat: 'yy-mm-dd' ,    	
	        altFormat: "yy-mm-dd",       
	    	changeMonth: true,
	    	changeYear: true ,	   
		    minDate: 0,
		    prevText: js_lang.datep_1,
			nextText: js_lang.datep_2,
			currentText: js_lang.datep_3,
			monthNames: [js_lang.January,js_lang.February,js_lang.March,js_lang.April,js_lang.May,js_lang.June,
			js_lang.July,js_lang.August,js_lang.September,js_lang.October,js_lang.November,js_lang.December],
			monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
			js_lang.Jul, js_lang.Aug, js_lang.Sep, js_lang.Oct, js_lang.Nov, js_lang.Dec],
			dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
			dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
			dayNamesMin: [js_lang.Su,js_lang.Mo,js_lang.Tu,js_lang.We,js_lang.Th,js_lang.Fr,js_lang.Sa],
			isRTL: false		
		});	
	}
	
	if ( $("#disabled_voucher_code").exists()){		
		$( document ).on( "click", "#voucher_name", function() {
			$(this).blur();
		});
	}	
	
});		
/*END version 2.1.1*/


/*START version 2.4*/
jQuery(document).ready(function() {	
	
	$( document ).on( "click", ".not_available", function() {        
		 busy(true);   
		 var params="action=UpdateItemAvailable&item_id="+$(this).val()+"&checked="+$(this.checked).length;
		 $.ajax({    
	        type: "POST",
	        url: ajax_url,
	        data: params,
	        dataType: 'json',       
	        success: function(data){           	        	
	        	busy(false);   
	        	if (data.code==1){
	        		uk_msg_sucess(data.msg);
	        	} else {
	        		uk_msg(data.msg);
	        	}
	        }, 
	        error: function(){                	
	        	busy(false); 
	        }		
	    });
    });
	
});

$.validate({ 	
	language : jsLanguageValidator,
    form : '#forms2',    
    onError : function() {      
    },
    onSuccess : function() {           
      form_submit('forms2');
      return false;
    }  
});
/*END version 2.4*/

/** START ADDED CODE VERSION 2.5*/

jQuery(document).ready(function() {	
	
	$( document ).on( "click", ".view-order-history", function() {    	       	 	
	   	var params="action=viewOrderHistory&tbl=viewReceipt&id="+ $(this).data("id")+"&backend=true"+"&currentController="+$("#currentController").val();
	    open_fancy_box(params);                     
	});	
	
   if ( $("#foodgallery").exists()){   
       createUploader('foodgallery','foodGallery');
    }       	

});	 /*ready*/

function foodGallery(data)
{
	var img='';
	$(".preview").show();
	img+='<li>';
	img+="<img src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\""+data.details.id+" uk-thumbnail uk-thumbnail-mini\" >";
	img+="<input type=\"hidden\" name=\"gallery_photo[]\" value=\""+data.details.file+"\" class=\""+data.details.id+"\" >";
	img+="<p class=\""+data.details.id+"\"><a href=\"javascript:rm_foodGallery('"+data.details.id+"');\">"+js_lang.removeFeatureImage+"</a></p>";
	img+='</li>';
	$(".foodgallery_preview").append(img);
}

function rm_foodGallery(id)
{	
	$("."+id).remove();
}

/** END ADDED CODE VERSION 2.5*/


/* ADDED CODE VERSION 3.0 */

jQuery(document).ready(function() {
	
	if ( $("#mobilelogo").exists() ) {   	
       createUploader('mobilelogo','mobileLogo');
    }   
    
    $('.website_enabled_mobile_verification').on('ifChecked', function(event){
    	$('.theme_enabled_email_verification').iCheck('uncheck');
    });
    $('.theme_enabled_email_verification').on('ifChecked', function(event){
    	$('.website_enabled_mobile_verification').iCheck('uncheck');
    });
	
}); /*end doc*/

function mobileLogo(data)
{
	var img='';
	img+="<img id=\"logo-small\" src=\""+upload_url+"/"+data.details.file+"\" alt=\"\" title=\"\" class=\"uk-thumbnail\" >";
	img+="<input type=\"hidden\" name=\"mobilelogo\" value=\""+data.details.file+"\" >";
	img+="<p><a href=\"javascript:rmMobileLogo();\">"+js_lang.removeFeatureImage+"</a></p>";
	$(".MobileLogoPreview").html(img);
}

function rmMobileLogo()
{
	$(".MobileLogoPreview").html('');
}

/* END ADDED CODE VERSION 3.0 */


jQuery(document).ready(function() {	
		
	$( document ).on( "click", ".show-cc-details", function() {
		var id=$(this).data("id");
		var params="action=showCCDetails&tbl=showCCDetails&backend=true"+
		"&currentController="+$("#currentController").val()+
		"&id="+id;
        open_fancy_box(params);       
	});
	
}); /*END DOCU*/